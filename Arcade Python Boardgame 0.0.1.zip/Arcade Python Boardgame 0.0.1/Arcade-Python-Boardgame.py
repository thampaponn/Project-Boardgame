from tkinter import *
import random, pygame
from wordsforhangman import word_list
from pygame.constants import K_DOWN

def check(choice):
    "check"
    if choice == "y":
        game_choice = input("Which game do you want to play? \n(Rock Paper Scissors(1), Number Guessing(2), Tic-Tac-Toe(3), Hangman(4), Fast Typing Game(5))")
        if game_choice == "1":
            print("Let's play Rock Paper Scissors!")
            def game_inter():
                """game interface"""
                p1_all_re = {'wins':0, 'losses':0, 'ties':0} #แถบแสดงผลทั้งหมด

                def game_rule(p1_shoot, p2_shoot): #กติกา
                    """rule of RPS"""
                    if p1_shoot == p2_shoot:
                        p1_all_re['ties'] += 1
                        return "tied"
                    elif (p1_shoot == "rock" and p2_shoot == "scissors") or (p1_shoot == "paper" and p2_shoot == "rock") or \
                        (p1_shoot == "scissors" and p2_shoot == "paper"):
                        p1_all_re['wins'] += 1
                        return "P1 won"
                    else:
                        p1_all_re['losses'] += 1
                        return "P1 lost"

                def on_click(e): #แสดงแถบผลการเล่นในรอบนั้นๆ
                    p1_shoot = e.widget["text"]
                    p2_shoot = random.choice(shoot)
                    result = game_rule(p1_shoot, p2_shoot)
                    tv_result.set(f'p1:{p1_shoot} - p2:{p2_shoot} >>> {result}')
                    result_all.set(f'{p1_all_re["wins"]} wins, {p1_all_re["ties"]} ties, {p1_all_re["losses"]} losses')

                root = Tk()
                root.option_add("*Font", "consolas 20")
                shoot = ['rock', 'paper', 'scissors']
                p1_shoot = [PhotoImage(file=f'{img}.png') for img in shoot]
                f1 = Frame(root)
                f1.grid(row=0, column=0)
                f2 = Frame(root)
                f2.grid(row=1, column=0)

                tv_result = StringVar()
                result_all = StringVar()

                for i in range(len(p1_shoot)):
                    w = Button(f1, image=p1_shoot[i], text=shoot[i], borderwidth=0)
                    w.pack(side=LEFT, padx=10)
                    w.bind('<Button-1>', on_click)
                Label(f2, textvariable=tv_result, width=40).pack()
                Label(f2, textvariable=result_all, width=40, bg="pink").pack()
                root.mainloop()
                playagain = input("Would you like to play this game again? (Y/N)").lower()
                if playagain == "y":
                    game_inter()
                elif playagain == "n":
                    playanothergame = input("Would you like to play other games? (Y/N)").lower()
                    if playanothergame == "y":
                        check(playanothergame)
                    elif playanothergame == "n":
                        print("Okay! See you next time!")
            game_inter()
        elif game_choice == "2":
            print("Let's play Guess the Number! (Guess the number between 0-1000)")
            def rdng():
                """Random num"""
                from random import randrange
                x_num = randrange(1000)
                count = 0
                while True:
                    put_num = int(input())
                    if x_num == put_num:
                        print("Correct!")
                        print("You've guessed the number %d time(s)!" %count)
                        playagain = input("Would you like to play this game again? (Y/N)").lower()
                        if playagain == "y":
                            print("Let's play Guess the Number! (Guess the number between 0-1000)")
                            rdng()
                        elif playagain == "n":
                            playanothergame = input("Would you like to play other games? (Y/N)").lower()
                            if playanothergame == "y":
                                check(playanothergame)
                            elif playanothergame == "n":
                                print("Okay! See you next time!")
                        break
                    if x_num < put_num:
                        print("Smaller")
                        count += 1
                    else:
                        print("Bigger")
                        count += 1
                        
            rdng()
        elif game_choice == "3":
            global board
            board = [' ' for x in range(10)]
            def insertBoard(letter, pos):
                global board
                board[pos] = letter

            def spaceIsFree(pos):
                return board[pos] == ' '

            def isWinner(bo, le):
                #this function returns True if that player has won.
                #bo = board le = letter
                return ((bo[7] == le and bo[8] == le and bo[9] == le) or #horizontal top line
                (bo[4] == le and bo[5] == le and bo[6] == le) or #horizontal mid line
                (bo[1] == le and bo[2] == le and bo[3] == le) or #horizontal bottom line
                (bo[7] == le and bo[4] == le and bo[1] == le) or #vertical left line
                (bo[8] == le and bo[5] == le and bo[2] == le) or #vertical mid line
                (bo[9] == le and bo[6] == le and bo[3] == le) or #vertical right line
                (bo[7] == le and bo[5] == le and bo[3] == le) or # diagonal
                (bo[9] == le and bo[5] == le and bo[1] == le)) # diagonal

            def playerMove():
                run = True
                while run:
                    move = input('Please select a position to place an \'X\' (1-9): ')
                    try:
                        move  = int(move)
                        if move > 0 and move < 10:
                            if spaceIsFree(move):
                                run = False
                                insertBoard('X', move)
                            else:
                                print('This postion is already occupied!')
                        else:
                            print('Please type a number within the range!')
                    except:
                        print('Please type a number!')

            def selectRandom(li):
                import random
                ln = len(li)
                r = random.randrange(0, ln)
                return li[r]

            def compMove():
                possibleMoves = [x for x, letter in enumerate(board) if letter == ' ' and x != 0]
                move = 0
                
                #Check for possible winning move to take or to block opponents winning move
                for let in ['O','X']:
                    for i in possibleMoves:
                        boardCopy = board[:]
                        boardCopy[i] = let
                        if isWinner(boardCopy, let):
                            move = i
                            return move

                #Try to take one of the corners
                cornersOpen = []
                for i in possibleMoves:
                    if i in [1,3,7,9]:
                        cornersOpen.append(i)
                if len(cornersOpen) > 0:
                    move = selectRandom(cornersOpen)
                    return move
                
                #Try to take the center
                if 5 in possibleMoves:
                    move = 5
                    return move

                #Take any edge
                edgesOpen = []
                for i in possibleMoves:
                    if i in [2,4,6,8]:
                        edgesOpen.append(i)

                if len(edgesOpen) > 0:
                    move = selectRandom(edgesOpen)

                return move

            def isBoardFull(board):
                if board.count(' ') > 1:
                    return False
                else:
                    return True

            def printBoard():
                # "board" = list of 10 strings representing the board (ignore index 0)
                print('   |   |')
                print(' ' + board[1] + ' | ' + board[2] + ' | ' + board[3])
                print('   |   |')
                print('-----------')
                print('   |   |')
                print(' ' + board[4] + ' | ' + board[5] + ' | ' + board[6])
                print('   |   |')
                print('-----------')
                print('   |   |')
                print(' ' + board[7] + ' | ' + board[8] + ' | ' + board[9])
                print('   |   |')

            def titi():
                #Main game loop
                print('Welcome to Tic Tac Toe, to win complete a straight line of your letter (Diagonal, Horizontal, Vertical). The board has positions 1-9 starting at the top left.')
                printBoard()

                while not(isBoardFull(board)):
                    if not(isWinner(board, 'O')):
                        playerMove()
                        printBoard()
                    else:
                        print('O\'s win this time...')
                        break
                    
                    if not(isWinner(board, 'X')):
                        move = compMove()
                        if move == 0:
                            print('Game is a Tie! No more spaces left to move.')
                        else:
                            insertBoard('O', move)
                            print('Computer placed an \'O\' in position', move, ':')
                            printBoard()
                    else:
                        print('X\'s win, good job!')
                        break

                if isBoardFull(board):
                    print('Game is a tie! No more spaces left to move.')

            titi()

            while True:
                answer = input('Do you want to play again? (Y/N)')
                if answer.lower() == 'y':
                    board = [' ' for x in range(10)]
                    print('-----------------------------------')
                    titi()
                elif answer.lower() == 'n':
                    playanothergame = input("Would you like to play other games? (Y/N)").lower()
                    if playanothergame == "y":
                        check(playanothergame)
                    elif playanothergame == "n":
                        print("Okay! See you next time!")
                    break
        elif game_choice == "4":
            def get_word():
                word = random.choice(word_list)
                return word.upper()
            #รับคำจาก word_list(ตัวแปรในwordsforhangman)


            def play(word):
                word_completion = "_" * len(word)#_ _ _ ช่องว่างสำหรับใส่ตัวอักษร
                guessed = False
                guessed_letters = []
                guessed_words = []
                tries = 6
                print("Let's play Hangman!")#Introduction
                print(display_hangman(tries))#เสา
                print(word_completion)#_ _ _ ช่องว่างสำหรับใส่ตัวอักษร
                print("\n")
                while not guessed and tries > 0:
                    guess = input("Guess a letter or word: ").upper()
                    if len(guess) == 1 and guess.isalpha():
                        if guess in guessed_letters:
                            print("You already guessed that letter")
                        elif guess not in word:
                            print(guess, "is not in the word.")
                            tries -= 1
                            guessed_letters.append(guess)
                        else:
                            print("YAYYY", guess, "is in the word!")
                            guessed_letters.append(guess)
                            word_as_list = list(word_completion)
                            indices = [i for i, letter in enumerate(word) if letter == guess]
                            for index in indices:
                                word_as_list[index] = guess
                            word_completion = "".join(word_as_list)
                            if "_" not in word_completion:
                                guessed = True
                    elif len(guess) == len(word) and guess.isalpha():
                        if guess in guessed_words:
                            print("You already guessed that word")
                        elif guess != word:
                            print(guess, "is not the word.")
                            tries -= 1
                            guessed_words.append(guess)
                        else:
                            guessed = True
                            word_completion = word
                    else:
                        print("Not a valid guess.")
                    print(display_hangman(tries))
                    print(word_completion)
                    print("\n")
                if guessed:
                    print("Congrats, you guessed the word! You win!")
                else:
                    print("T_T Out of tries. The word was " + word + ". Maybe next time!")



            def display_hangman(tries):
                stages = [  # หัว + ลำตัว + แขนซ้าย + แขนขวา + ขาซ้าย + ขาขวา ตายแน่ๆ
                            """
                            --------
                            |      |
                            |      O
                            |     \\|/
                            |      |
                            |     / \\
                            -
                            """,
                            # หัว + ลำตัว + แขนซ้าย + แขนขวา + ขาซ้าย
                            """
                            --------
                            |      |
                            |      O
                            |     \\|/
                            |      |
                            |     / 
                            -
                            """,
                            # หัว + ลำตัว + แขนซ้าย + แขนขวา
                            """
                            --------
                            |      |
                            |      O
                            |     \\|/
                            |      |
                            |      
                            -
                            """,
                            # หัว + ลำตัว + แขนซ้าย
                            """
                            --------
                            |      |
                            |      O
                            |     \\|
                            |      |
                            |     
                            -
                            """,
                            # หัว + ลำตัว
                            """
                            --------
                            |      |
                            |      O
                            |      |
                            |      |
                            |     
                            -
                            """,
                            # หัว
                            """
                            --------
                            |      |
                            |      O
                            |    
                            |      
                            |     
                            -
                            """,
                            # เริ่มต้น
                            """
                            --------
                            |      |
                            |      
                            |    
                            |      
                            |     
                            -
                            """
                ]
                return stages[tries]
            def hangman():
                word = get_word()
                play(word)
                playagain = input("Would you like to play this game again? (Y/N)").lower()
                if playagain == "y":
                    hangman()
                elif playagain == "n":
                    playanothergame = input("Would you like to play other games? (Y/N)").lower()
                    if playanothergame == "y":
                        check(playanothergame)
                    elif playanothergame == "n":
                        print("Okay! See you next time!")
            hangman()
        elif game_choice == "5":
            #Initialize Pygame
            pygame.init()

            #ไอคอนเกมและชื่อ
            pygame.display.set_caption (' Project Typing Game ') #ชื่อเกม
            #icon = pygame.image.load ('game.png') #เปลี่ยนไอคอนเกม
            #pygame.display.set_icon (icon)

            global chosenword, pressedword, word_x, word_y, text, pointcount, speed
            x = 600
            y = 400

            speed = 0.05
            purple = (170, 0, 200)
            darkblue = (0,20,90)
            background = (200, 200, 250)
            point = 0
            pressedword = ""

            #ฟังก์ชั่นคำศัพท์
            def new_word():
                global chosenword, pressedword, word_x, word_y, text, pointcount, speed
                word_x = random.randint(100, 500)
                word_y = 0
                speed += 0.005
                pressedword = ""
                lines = open("words.txt").read().splitlines()
                chosenword = random.choice(lines)
                text = font.render(chosenword, True, purple)
            font = pygame.font.SysFont("CosmicSansMs", 32)
            screen = pygame.display.set_mode((x, y))
            new_word()
            running = True
            #Game loop
            while running:  
                screen.fill(background)
                word_y += speed
                screen.blit(text, (word_x, word_y))
                text 
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        playanothergame = input("Would you like to play other games? (Y/N)").lower()
                        if playanothergame == "y":
                            check(playanothergame)
                        elif playanothergame == "n":
                            print("Okay! See you next time!")
                    elif event.type == pygame.KEYDOWN:
                        pressedword += pygame.key.name(event.key)
                        if chosenword.startswith(pressedword):
                            if chosenword == pressedword:
                                point += 1
                                new_word()
                        else:
                            pressedword = ""

                pointcaption = font.render(str(point), True, darkblue)
                screen.blit(pointcaption, (10,5))
                again = font.render(str("KeyDown To Try Again!!"), True, darkblue)
                if word_y < y-5:
                    pygame.display.update()
                else:
                    event = pygame.event.wait()
                    screen.blit(again, (150,250))
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN: #ลูกศรลงเพื่อรีสตาร์ทเกม
                        speed = 0.05
                        point = 0
                        new_word()
                pygame.display.update()
                
        else:
            print("Invalid Name! Please re-enter the game!")
    elif choice == "n":
        print("It's okay, Maybe next time!")
    else:
        print("Invalid Name! Please re-enter the game.")
def main():
    """choose game"""
    choice = input("Welcome to the Arcade Python Boardgame! Are you ready? (Y/N)").lower()
    check(choice)
main()
